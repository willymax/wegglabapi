<div>
    Price: There is no price
</div>
<?php /**PATH D:\wegglab\api3\resources\views/emails/test.blade.php ENDPATH**/ ?>