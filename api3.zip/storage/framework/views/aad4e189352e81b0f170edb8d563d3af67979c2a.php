There was an error
<?php /**PATH D:\wegglab\api3\resources\views/errors/503.blade.php ENDPATH**/ ?>