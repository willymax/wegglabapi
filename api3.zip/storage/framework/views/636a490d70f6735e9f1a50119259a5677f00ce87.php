<?php echo e($slot); ?>

<?php /**PATH D:\wegglab\api3\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>