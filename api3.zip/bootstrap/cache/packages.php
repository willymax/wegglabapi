<?php return array (
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'laravel-json-api/encoder-neomerx' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelJsonApi\\Encoder\\Neomerx\\ServiceProvider',
    ),
  ),
  'laravel-json-api/laravel' => 
  array (
    'aliases' => 
    array (
      'JsonApi' => 'LaravelJsonApi\\Core\\Facades\\JsonApi',
      'JsonApiRoute' => 'LaravelJsonApi\\Laravel\\Facades\\JsonApiRoute',
    ),
    'providers' => 
    array (
      0 => 'LaravelJsonApi\\Laravel\\ServiceProvider',
    ),
  ),
  'laravel-json-api/spec' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelJsonApi\\Spec\\ServiceProvider',
    ),
  ),
  'laravel-json-api/validation' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelJsonApi\\Validation\\ServiceProvider',
    ),
  ),
  'laravel/fortify' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Fortify\\FortifyServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/socialite' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    ),
    'aliases' => 
    array (
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
);