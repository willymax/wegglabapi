<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AnswerFileController extends Controller
{
    //
}
